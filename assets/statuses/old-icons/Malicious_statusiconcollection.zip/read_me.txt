Thanks for downloading the Status icon Collection. It means a lot.

This asset pack is made possible with the use of DALL-E 3 by OpenAI.
My work involves refining, finetuning, compilation, optimization and edition to provide you with quality assets.

I am not claiming full rights on the provided assets. I am claiming partial rights due to manual transformation of those assets.

The following license applies to the assets in the folders labelled "free assets":

License CC-BY
  - You can copy and redistribute the material in any medium or format for any purpose, even commercially.
  - You can remix, transform, and build upon the material for any purpose, even commercially.
  - You must give credit to TrulyMalicious

https://creativecommons.org/licenses/by/4.0/

The following license applies to the assets in the folders labelled "premium assets":

License
  - The initial purchaser of these assets can copy and redistribute the material in any medium or format for any purpose, even commercially.
  - The initial purchaser of these assets can remix, transform, and build upon the material for any purpose, even commercially.
  - You must give credit to TrulyMalicious
  - Third parties cannot copy or redistribute the material, even if modified. This applies to any user obtaining access to these assets through other means that purchase of those assets.

Follow me on Twitter for future updates :
https://twitter.com/trulymalicious

If you enjoy this then leave a rating and comment. It helps to support this project! :D
